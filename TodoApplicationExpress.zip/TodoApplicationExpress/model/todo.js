var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    taskdescription: {
        type: String,
       
    },
    taskduedate: {
        type: String,
       
    },

    completed: {
        type: String,
       
    },
    
});
var todo = new mongoose.model('Todo', schema);
module.exports = todo;
