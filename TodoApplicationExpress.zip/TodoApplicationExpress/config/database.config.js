module.exports = {
    url: 'mongodb+srv://FurqanRaza10:Rizvi101201@cluster0.3cc0uhf.mongodb.net/?retryWrites=true&w=majority'
}