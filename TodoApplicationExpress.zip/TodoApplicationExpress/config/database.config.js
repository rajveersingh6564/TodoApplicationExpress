module.exports = {
    url: 'hrajveer191:hrajveer191@cluster0.kssjwym.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
}

